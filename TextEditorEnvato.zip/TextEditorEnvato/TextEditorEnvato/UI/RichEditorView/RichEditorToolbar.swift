//
//  File.swift
//  RichEditor
//
//  Created by Khayala Hasanli on 09.05.22.
//

import UIKit

@objcMembers open class RichEditorToolbar: UIView {

    open weak var delegate: RichEditorToolbarDelegate?
    open weak var editor: RichEditorView?
    
    open var options: [RichEditorOption] = [] {
        didSet {
        }
    }


    public override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    private func setup() {
        editor?.delegate = self
        autoresizingMask = .flexibleWidth
        backgroundColor = .black
    }

}

extension RichEditorToolbar : RichEditorDelegate{
    
}
