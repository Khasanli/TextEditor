//
//  File.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 05.06.22.
//

import UIKit

class RichEditorToolButton: UIButton {
//Swift
    open var actionHandler: (() -> Void)?
   
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addTarget(self, action: #selector(buttonWasTapped), for: .touchUpInside)
    }
    
    @objc func buttonWasTapped() {
        actionHandler?()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class RichEditorToolDoubleButton: UIView {
    open var actionHandler: (() -> Void)?

    let firstButton = UIButton(image: UIImage(systemName: "text.alignleft"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let moreButton = UIButton(image: UIImage(systemName: "chevron.down"), title: nil, tintColor: .clear, backgroundColor: .clear)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .yellow
        setView()
    }
    
    func setView(){
        addSubview(firstButton)
        firstButton.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        firstButton.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        firstButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 2/3).isActive = true
        firstButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 2/3).isActive = true
        firstButton.tintColor = .gray
        firstButton.backgroundColor = .secondaryLabel
        
        addSubview(moreButton)
        moreButton.centerYAnchor.constraint(equalTo: firstButton.centerYAnchor).isActive = true
        moreButton.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        moreButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/3).isActive = true
        moreButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier:  1/6).isActive = true
        moreButton.tintColor = .secondaryLabel
    }
    
    @objc func firstButtonTapped(){
        actionHandler?()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
