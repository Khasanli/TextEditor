//
//  ViewController.swift
//  TextEditorEnvato
//
//  Created by Khayala Hasanli on 21.06.22.
//

import UIKit

class ViewController: UIViewController {
    
    let textEditor = FullTextEditorView(backgroundColor: .clear)
    var changeTextColor = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .secondarySystemBackground
        setView()
    }
    
    private func setView(){
        view.addSubview(textEditor)
        textEditor.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 25).isActive = true
        textEditor.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
        textEditor.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
        textEditor.heightAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1.5).isActive = true
        textEditor.editorToolView.selectTextColor.addTarget(self, action: #selector(setTextColorButtonTapped), for: .touchUpInside)
        textEditor.editorToolView.selectTextBGColor.addTarget(self, action: #selector(setTextBGColorButtonTapped), for: .touchUpInside)
    }
    
    @objc func setTextColorButtonTapped(){
        changeTextColor = true
        if #available(iOS 14.0, *) {
            let textColorPicker = UIColorPickerViewController()
            textColorPicker.delegate = self
            present(textColorPicker, animated: true, completion: nil)
        } else {
            showColorPicker()
        }
    }
    
    @objc func setTextBGColorButtonTapped(){
        changeTextColor = false
        if #available(iOS 14.0, *) {
            let textBGColorPicker = UIColorPickerViewController()
            textBGColorPicker.delegate = self
            present(textBGColorPicker, animated: true, completion: nil)
        } else {
            showColorPicker()
        }
    }
    
    private func showColorPicker(){
        let colorPickerVc = ColorPickerViewController()
        colorPickerVc.modalPresentationStyle = .popover
        colorPickerVc.preferredContentSize = CGSize.init(width: 265, height: 410)
        colorPickerVc.colorPickerDelegate = self
        
        if let popoverController = colorPickerVc.popoverPresentationController {
            popoverController.sourceView = self.view
            popoverController.sourceRect = self.textEditor.editorView.frame
            popoverController.permittedArrowDirections = UIPopoverArrowDirection.any
            popoverController.delegate = self
        }
        present(colorPickerVc, animated: true, completion: nil)
    }
}

@available(iOS 14.0, *)
extension ViewController: UIColorPickerViewControllerDelegate {
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        let color = viewController.selectedColor
        if changeTextColor {
            self.textEditor.editorToolView.selectedTextUIColor = color
        } else {
            self.textEditor.editorToolView.selectedTextBGUIColor = color
        }
    }

    func colorPickerViewController(_ viewController: UIColorPickerViewController, didSelect color: UIColor, continuously: Bool) {
        let color = viewController.selectedColor
        if changeTextColor {
            self.textEditor.editorToolView.selectedTextUIColor = color
        } else {
            self.textEditor.editorToolView.selectedTextBGUIColor = color
        }
    }
}

extension ViewController: UIPopoverPresentationControllerDelegate, ColorPickerDelegate{
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
            return UIModalPresentationStyle.none
        }
        
    func colorPickerDidColorSelected(selectedUIColor: UIColor, selectedHexColor: String) {
        if changeTextColor {
            self.textEditor.editorToolView.selectedTextUIColor = selectedUIColor
        } else {
            self.textEditor.editorToolView.selectedTextBGUIColor = selectedUIColor
        }
    }
}

