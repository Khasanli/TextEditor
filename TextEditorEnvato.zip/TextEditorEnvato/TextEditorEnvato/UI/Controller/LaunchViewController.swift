//
//  LaunchViewController.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 21.06.22.
//

import UIKit

class LaunchViewController: UIViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .secondarySystemBackground
    }
    
}
