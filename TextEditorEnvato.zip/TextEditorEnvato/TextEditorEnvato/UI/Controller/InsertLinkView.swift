//
//  InsertLinkView.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 06.06.22.
//

import UIKit

class InsertLinkView: UIView {
    let bg = UIView(backgroundColor: .clear)
    let contentBG = UIView(backgroundColor: .white)
    let content = UIView(backgroundColor: .secondarySystemFill)

    let httpTextTitle = UILabel(text: "URL", backgroundColor: .clear, textColor: .tertiarySystemBackground, font: UIFont(name: "Arial", size: 15)!)
    
    let httpTextField = UITextField(placeholder: "http//", backgroundColor: .tertiarySystemBackground, textColor: .tertiaryLabel, font: UIFont(name: "Arial", size: 15)!)
    
    let textTitle = UILabel(text: "TEXT", backgroundColor: .clear, textColor: .tertiarySystemBackground, font: UIFont(name: "Arial", size: 12)!)
    
    let textTextField = UITextField(placeholder: "", backgroundColor: .tertiarySystemBackground, textColor: .tertiaryLabel, font: UIFont(name: "Arial", size: 15)!)
    
    let InsertButton = UIButton(image: nil, title: "Insert", tintColor: .clear, backgroundColor: .clear)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setView()
    }
    
    func setView(){
        addSubview(bg)
        bg.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        bg.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        bg.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        bg.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true

        addSubview(contentBG)
        contentBG.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        contentBG.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        contentBG.widthAnchor.constraint(equalTo: self.widthAnchor, constant: -20).isActive = true
        contentBG.heightAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        contentBG.layer.shadowColor = UIColor.systemFill.cgColor
        contentBG.layer.cornerRadius = 5
        contentBG.layer.shadowRadius = 5
        contentBG.layer.shadowOpacity = 0.5
        contentBG.backgroundColor = .secondaryLabel
        
        addSubview(content)
        content.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        content.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        content.widthAnchor.constraint(equalTo: self.widthAnchor, constant: -20).isActive = true
        content.heightAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        content.layer.cornerRadius = 5

        addSubview(httpTextTitle)
        httpTextTitle.topAnchor.constraint(equalTo: content.topAnchor, constant: 10).isActive = true
        httpTextTitle.centerXAnchor.constraint(equalTo: content.centerXAnchor).isActive = true
        httpTextTitle.widthAnchor.constraint(equalTo: content.widthAnchor, constant: -20).isActive = true
        httpTextTitle.heightAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/6).isActive = true
        httpTextTitle.textAlignment = .left
        
        addSubview(httpTextField)
        httpTextField.topAnchor.constraint(equalTo: httpTextTitle.bottomAnchor).isActive = true
        httpTextField.centerXAnchor.constraint(equalTo: content.centerXAnchor).isActive = true
        httpTextField.widthAnchor.constraint(equalTo: content.widthAnchor, constant: -20).isActive = true
        httpTextField.heightAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/6).isActive = true
        httpTextField.textAlignment = .left
        httpTextField.leftViewMode = .always
        httpTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        httpTextField.layer.cornerRadius = 3
        httpTextField.layer.shadowColor = UIColor.lightGray.cgColor
        httpTextField.layer.shadowRadius = 3
        httpTextField.layer.shadowOpacity = 0.5

        addSubview(textTitle)
        textTitle.topAnchor.constraint(equalTo: httpTextField.bottomAnchor, constant: 10).isActive = true
        textTitle.centerXAnchor.constraint(equalTo: content.centerXAnchor).isActive = true
        textTitle.widthAnchor.constraint(equalTo: content.widthAnchor, constant: -20).isActive = true
        textTitle.heightAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/6).isActive = true
        textTitle.textAlignment = .left
        
        addSubview(textTextField)
        textTextField.topAnchor.constraint(equalTo: textTitle.bottomAnchor).isActive = true
        textTextField.centerXAnchor.constraint(equalTo: content.centerXAnchor).isActive = true
        textTextField.widthAnchor.constraint(equalTo: content.widthAnchor, constant: -20).isActive = true
        textTextField.heightAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/6).isActive = true
        textTextField.textAlignment = .left
        textTextField.leftViewMode = .always
        textTextField.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: 10))
        textTextField.layer.cornerRadius = 3
        textTextField.layer.shadowColor = UIColor.lightGray.cgColor
        textTextField.layer.shadowRadius = 3
        textTextField.layer.shadowOpacity = 0.5
        
        addSubview(InsertButton)
        InsertButton.topAnchor.constraint(equalTo: textTextField.bottomAnchor, constant: 10).isActive = true
        InsertButton.centerXAnchor.constraint(equalTo: content.centerXAnchor).isActive = true
        InsertButton.widthAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/2, constant: -20).isActive = true
        InsertButton.heightAnchor.constraint(equalTo: content.widthAnchor, multiplier: 1/8).isActive = true
        InsertButton.backgroundColor = .tertiarySystemBackground
        InsertButton.setTitleColor(.tertiaryLabel, for: .normal)
        InsertButton.layer.cornerRadius = 3
        InsertButton.layer.shadowColor = UIColor.lightGray.cgColor
        InsertButton.layer.shadowRadius = 3
        InsertButton.layer.shadowOpacity = 0.5
        InsertButton.titleLabel?.font = UIFont(name: "Arial", size: 15)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
