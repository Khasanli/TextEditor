//
//  LaunchScreenUIView.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 21.06.22.
//

import UIKit

class LaunchScreenUIView : UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .yellow
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
