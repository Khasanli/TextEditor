//
//  RichEditorToolbar.swift
//
//  Created by Caesar Wirth on 4/2/15.
//  Copyright (c) 2015 Caesar Wirth. All rights reserved.
//
import UIKit

@objc public protocol RichEditorToolbarDelegate: AnyObject {

    @objc optional func richEditorToolbarChangeTextColor(_ toolbar: RichEditorToolbar)
    @objc optional func richEditorToolbarChangeSelectTextColor(_ toolbar: RichEditorToolbar)

    @objc optional func richEditorToolbarChangeBackgroundColor(_ toolbar: RichEditorToolbar)
    @objc optional func richEditorToolbarChangeSelectTextBackgroundColor(_ toolbar: RichEditorToolbar)

    @objc optional func richEditorToolbarInsertImage(_ toolbar: RichEditorToolbar)

    @objc optional func richEditorToolbarInsertVideo(_ toolbar: RichEditorToolbar)

    @objc optional func richEditorToolbarInsertLink(_ toolbar: RichEditorToolbar)
    
    @objc optional func richEditorToolbarInsertTable(_ toolbar: RichEditorToolbar)
}

@objcMembers open class RichBarButtonItem: UIBarButtonItem {
    open var actionHandler: (() -> Void)?
    
    public convenience init(image: UIImage? = nil, handler: (() -> Void)? = nil) {
        self.init(image: image, style: .plain, target: nil, action: nil)
        target = self
        action = #selector(RichBarButtonItem.buttonWasTapped)
        actionHandler = handler
    }
    
    public convenience init(title: String = "", handler: (() -> Void)? = nil) {
        self.init(title: title, style: .plain, target: nil, action: nil)
        target = self
        action = #selector(RichBarButtonItem.buttonWasTapped)
        actionHandler = handler
    }
    
    @objc func buttonWasTapped() {
        actionHandler?()
    }
}

