//
//  File.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 05.06.22.
//

import UIKit

class FullTextEditorView : UIView {
    var prevText: String!

    var EditorToolViewHeightAnchor: NSLayoutConstraint?
    var EditorToolBGViewHeightAnchor: NSLayoutConstraint?
    var EditorToolViewOpen: Bool = false

    let themeButton = UIButton(configuration: false, image: UIImage(systemName: "moon.fill"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let editButton = UIButton(configuration: false, image: UIImage(systemName: "pencil"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let editorView = RichEditorView(backgroundColor: .clear)
    let editorGestureView = UIView(backgroundColor: .clear)
    let editorToolBGView = UIView(backgroundColor: .tertiarySystemFill)
    let editorToolView = RichEditorToolUIView(backgroundColor: .clear)
    var editorWordCountTitle = UILabel(text: "Word Count: ", backgroundColor: .clear, textColor: .secondaryLabel, font: UIFont(name: "Arial-ItalicMT", size: 16)!)
    var editorWordCountText = UILabel(text: "0", backgroundColor: .clear, textColor: .secondaryLabel, font: UIFont(name: "Arial-BoldMT", size: 16)!)
    
    private func setView(){
        addSubview(themeButton)
        themeButton.topAnchor.constraint(equalTo: topAnchor).isActive = true
        themeButton.rightAnchor.constraint(equalTo: rightAnchor, constant: -25).isActive = true
        themeButton.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 1/8).isActive = true
        themeButton.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 1/8).isActive = true
        themeButton.layer.cornerRadius = 25
        themeButton.backgroundColor = .secondarySystemFill
        themeButton.tintColor = .secondaryLabel
        themeButton.addTarget(self, action: #selector(onClickThemeButton), for: .touchUpInside)
        
        addSubview(editButton)
        editButton.topAnchor.constraint(equalTo: topAnchor).isActive = true
        editButton.rightAnchor.constraint(equalTo: themeButton.leftAnchor, constant: -10).isActive = true
        editButton.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 1/8).isActive = true
        editButton.widthAnchor.constraint(equalTo: widthAnchor, multiplier: 1/8).isActive = true
        editButton.layer.cornerRadius = 25
        editButton.backgroundColor = .secondarySystemFill
        editButton.tintColor = .secondaryLabel
        editButton.addTarget(self, action: #selector(onClickEditButton), for: .touchUpInside)
        
        addSubview(editorView)
        editorView.topAnchor.constraint(equalTo: editButton.bottomAnchor, constant: 20).isActive = true
        editorView.leftAnchor.constraint(equalTo: leftAnchor, constant: 25).isActive = true
        editorView.rightAnchor.constraint(equalTo: rightAnchor, constant: -25).isActive = true
        editorView.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 2/3).isActive = true
        editorView.layer.shadowColor = UIColor.secondarySystemFill.cgColor
        editorView.setEditorBackgroundColor(.black)
        editorView.layer.shadowOpacity = 1
        editorView.layer.shadowRadius = 5
        
        addSubview(editorGestureView)
        editorGestureView.topAnchor.constraint(equalTo: editButton.bottomAnchor, constant: 20).isActive = true
        editorGestureView.leftAnchor.constraint(equalTo: leftAnchor, constant: 25).isActive = true
        editorGestureView.rightAnchor.constraint(equalTo: rightAnchor, constant: -25).isActive = true
        editorGestureView.heightAnchor.constraint(equalTo: widthAnchor, multiplier: 2/3).isActive = true
        editorGestureView.isHidden = true
        
        addSubview(editorToolBGView)
        editorToolBGView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        editorToolBGView.leftAnchor.constraint(equalTo: leftAnchor, constant: 25).isActive = true
        editorToolBGView.rightAnchor.constraint(equalTo: editButton.leftAnchor, constant: -10).isActive = true
        editorToolBGView.layer.cornerRadius = 5
        editorToolBGView.layer.shadowColor = UIColor.tertiaryLabel.cgColor
        editorToolBGView.layer.masksToBounds = false
        editorToolBGView.layer.shadowOpacity = 1
        editorToolBGView.layer.shadowOffset = .zero
        editorToolBGView.layer.shadowRadius = 5
        EditorToolBGViewHeightAnchor = editorToolBGView.heightAnchor.constraint(equalToConstant: screenSize.width/8)
        EditorToolBGViewHeightAnchor?.isActive = true
        
        addSubview(editorToolView)
        editorToolView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor).isActive = true
        editorToolView.leftAnchor.constraint(equalTo: leftAnchor, constant: 25).isActive = true
        editorToolView.rightAnchor.constraint(equalTo: editButton.leftAnchor, constant: -10).isActive = true
        editorToolView.layer.shadowColor = UIColor.lightGray.cgColor
        editorToolView.layer.masksToBounds = true
        editorToolView.layer.shadowOpacity = 0.5
        editorToolView.backgroundColor = .clear
        editorToolView.layer.shadowOffset = .zero
        editorToolView.layer.shadowRadius = 5
        editorToolView.layer.cornerRadius = 5
        EditorToolViewHeightAnchor = editorToolView.heightAnchor.constraint(equalToConstant: screenSize.width/8)
        EditorToolViewHeightAnchor?.isActive = true
        
        let gestureLinkView = UITapGestureRecognizer(target: self, action:  #selector (closeToolView))
        editorGestureView.addGestureRecognizer(gestureLinkView)
        
        addSubview(editorWordCountText)
        editorWordCountText.topAnchor.constraint(equalTo: editorView.bottomAnchor, constant: 5).isActive = true
        editorWordCountText.rightAnchor.constraint(equalTo: editorView.rightAnchor).isActive = true
        editorWordCountText.heightAnchor.constraint(equalToConstant: 40).isActive = true
        editorWordCountText.backgroundColor = .clear

        addSubview(editorWordCountTitle)
        editorWordCountTitle.topAnchor.constraint(equalTo: editorView.bottomAnchor, constant: 5).isActive = true
        editorWordCountTitle.rightAnchor.constraint(equalTo: editorWordCountText.leftAnchor).isActive = true
        editorWordCountTitle.heightAnchor.constraint(equalToConstant: 40).isActive = true
        editorWordCountTitle.backgroundColor = .clear
    }
    
    @objc private func onClickThemeButton(){
        if #available(iOS 13.0, *) {
            let appDelegate = UIApplication.shared.keyWindow
            if appDelegate?.overrideUserInterfaceStyle == .light {
                themeButton.setImage(UIImage(systemName: "sun.max.fill"), for: .normal)
                appDelegate?.overrideUserInterfaceStyle = .dark
                  return
            } else {
                themeButton.setImage(UIImage(systemName: "moon.fill"), for: .normal)
                appDelegate?.overrideUserInterfaceStyle = .light
                return
            }
        }
    }
    
    @objc private func onClickEditButton(){
        print(EditorToolViewOpen)
        if EditorToolViewOpen{
            self.EditorToolViewHeightAnchor?.constant = screenSize.width/8
            self.EditorToolBGViewHeightAnchor?.constant = screenSize.width/8
            self.editorToolView.InsertNewLinkView.isHidden = true
            self.editorGestureView.isHidden = true
            editorToolView.layoutSubviews()
            editorToolBGView.layoutSubviews()
            EditorToolViewOpen = !EditorToolViewOpen
        } else {
            self.EditorToolViewHeightAnchor?.constant = screenSize.width
            self.EditorToolBGViewHeightAnchor?.constant = screenSize.width
            self.editorGestureView.isHidden = false
            editorToolView.layoutSubviews()
            editorToolBGView.layoutSubviews()
            EditorToolViewOpen = !EditorToolViewOpen
        }
    }
    
    @objc private func closeToolView(){
        if EditorToolViewOpen{
            self.EditorToolViewHeightAnchor?.constant = screenSize.width/8
            self.EditorToolBGViewHeightAnchor?.constant = screenSize.width/8
            self.editorToolView.InsertNewLinkView.isHidden = true
            self.editorGestureView.isHidden = true
            editorToolView.layoutSubviews()
            editorToolBGView.layoutSubviews()
            EditorToolViewOpen = !EditorToolViewOpen
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        editorView.delegate = self
        editorView.editingEnabled = true
        editorView.placeholder = "Press to start typing"
        editorToolView.toolbar.editor = editorView
        editorToolView.toolbar.delegate = self
        editorView.html = ""
        setView()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension FullTextEditorView: RichEditorDelegate, RichEditorToolbarDelegate {
    func richEditor(_ editor: RichEditorView, contentDidChange content: String) {
        if content.count > 40000 {
            editor.html = prevText
        } else {
            prevText = content
            closeToolView()
            editorView.getTextCount { count in
                self.editorWordCountText.text = "\(count ?? 0)"
            }
        }
    }
    func richEditorTookFocus(_ editor: RichEditorView) {
        closeToolView()
    }
}
