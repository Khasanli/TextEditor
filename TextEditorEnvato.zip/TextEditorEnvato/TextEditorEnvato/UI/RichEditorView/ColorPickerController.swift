//
//  ColorPickerController.swift
//  CeltTask
//
//  Created by Khayala Hasanli on 12.05.22.
//

import UIKit

protocol ColorPickerDelegate {
    func colorPickerDidColorSelected(selectedUIColor: UIColor, selectedHexColor: String)
}

class ColorPickerViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    var colorPickerDelegate : ColorPickerDelegate?
    
    let colorCollectionView : UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .vertical
        flowLayout.minimumLineSpacing = 24
        flowLayout.sectionInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        flowLayout.itemSize = CGSize(width: 30, height: 30)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.backgroundColor = .darkText
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "ColorPickerCollectionViewCell")
        return collectionView
    }()

    var colorList = [String]() {
        didSet {
            self.colorCollectionView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        view.addSubview(colorCollectionView)
        self.colorCollectionView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        self.colorCollectionView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        self.colorCollectionView.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -100).isActive = true
        self.colorCollectionView.heightAnchor.constraint(equalTo: view.heightAnchor, constant: -400).isActive = true

        self.colorCollectionView.delegate = self
        self.colorCollectionView.dataSource = self
        
        self.loadColorList()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.colorList.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ColorPickerCollectionViewCell", for: indexPath)
        
        cell.backgroundColor = self.convertHexToUIColor(hexColor: self.colorList[indexPath.row])
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let clickedHexColor = self.colorList[indexPath.row]
        
        let clickedUIColor = self.convertHexToUIColor(hexColor: clickedHexColor)
        
        self.colorPickerDelegate?.colorPickerDidColorSelected(selectedUIColor: clickedUIColor, selectedHexColor: clickedHexColor)
        
        self.closeColorPicker()
    }
    
    private func loadColorList(){
    
        let colorFilePath = Bundle.main.path(forResource: "Colors", ofType: "plist")
        let colorNSArray = NSArray(contentsOfFile: colorFilePath!)
        
        self.colorList = colorNSArray as! [String]
    }
    
        private func convertHexToUIColor(hexColor : String) -> UIColor {
            let _hexString: String = hexColor.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            let scanner = Scanner(string: _hexString)
            if (_hexString.hasPrefix("#")) {
                scanner.currentIndex = scanner.string.index(after: scanner.currentIndex)
            }
            var color: UInt64 = 0
            scanner.scanHexInt64(&color)
            let mask = 0x000000FF
            let r = Int(color >> 16) & mask
            let g = Int(color >> 8) & mask
            let b = Int(color) & mask
            let red = CGFloat(r) / 255.0
            let green = CGFloat(g) / 255.0
            let blue = CGFloat(b) / 255.0
            return UIColor.init(red:red, green:green, blue:blue, alpha:1)
        }
    
    private func closeColorPicker(){
        self.dismiss(animated: true, completion: nil)
    }

}
