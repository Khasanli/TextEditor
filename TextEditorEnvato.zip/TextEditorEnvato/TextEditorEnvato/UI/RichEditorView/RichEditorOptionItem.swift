//
//  RichEditorOptionItem.swift
//
//  Created by Caesar Wirth on 4/2/15.
//  Copyright (c) 2015 Caesar Wirth. All rights reserved.
//
import UIKit

public protocol RichEditorOption {
    var image: UIImage? { get }
    var title: String { get }
    func action(_ editor: RichEditorToolbar)
}

public struct RichEditorOptionItem: RichEditorOption {

    public var image: UIImage?

    public var title: String

    public var handler: ((RichEditorToolbar) -> Void)

    public init(image: UIImage?, title: String, action: @escaping ((RichEditorToolbar) -> Void)) {
        self.image = image
        self.title = title
        self.handler = action
    }
        
    public func action(_ toolbar: RichEditorToolbar) {
        handler(toolbar)
    }
}

public enum RichEditorDefaultOption: RichEditorOption {

    case clear
    case undo
    case redo
    case bold
    case italic
    case underline
    case checkbox
    case `subscript`
    case superscript
    case strike
    case textColor
    case selectTextColor
    case textBackgroundColor
    case selectTextBackgroundColor
    case header(Int)
    case indent
    case outdent
    case orderedList
    case unorderedList
    case alignLeft
    case alignCenter
    case alignFull
    case alignRight
    case image
    case video
    case link
    case table
    
    public static let all: [RichEditorDefaultOption] = [
        .clear,
        .undo,
        .redo,
        .bold,
        .italic,
        .underline,
        .checkbox,
        .subscript,
        .superscript,
        .strike,
        .selectTextColor,
        .textColor,
        .textBackgroundColor,
        .selectTextBackgroundColor,
        .header(1), .header(2), .header(3), .header(4), .header(5), .header(6),
        .indent, outdent, orderedList, unorderedList,
        .alignLeft, .alignCenter, .alignRight, .alignFull, .image, .video, .link, .table
    ]
    
    public static let alignLists: [RichEditorDefaultOption] = [
        .alignLeft, .alignCenter, .alignRight, .alignFull
    ]
    
    public var image: UIImage? {
        var name : String?
        var systemName : String?
        switch self {
        case .clear: systemName = "clear"
        case .undo: systemName = "arrow.uturn.backward"
        case .redo: systemName = "arrow.uturn.forward"
        case .bold: systemName = "bold"
        case .italic: systemName = "italic"
        case .underline: systemName = "underline"
        case .checkbox: systemName = "checkbox"
        case .subscript: systemName = "subscript"
        case .superscript: systemName = "superscript"
        case .strike: systemName = "strikethrough"
        case .textColor: systemName = "pencil.tip"
        case .selectTextColor: systemName = "pencil.tip"
        case .textBackgroundColor: systemName = "paintpalette.fill"
        case .selectTextBackgroundColor: systemName = "arrowdown"
        case .header(let h): name = "h\(h)"
        case .indent: systemName = "text.chevron.left"
        case .outdent: systemName = "text.chevron.right"
        case .orderedList: systemName = "list.number"
        case .unorderedList: systemName = "list.bullet"
        case .alignLeft: systemName = "text.alignleft"
        case .alignFull: systemName = "text.justify"
        case .alignCenter: systemName = "text.aligncenter"
        case .alignRight: systemName = "text.alignright"
        case .image: systemName = "photo.artframe"
        case .video: systemName = "photo.artframe"
        case .link: systemName = "link"
        case .table: systemName = "photo.artframe"
        }
        if let name = name {
            return UIImage(named: name, in: .main, compatibleWith: nil)
        } else {
            return UIImage(systemName: systemName!, compatibleWith: nil)
        }
        
    }
    
    public var title: String {
        switch self {
        case .clear: return NSLocalizedString("Clear", comment: "")
        case .undo: return NSLocalizedString("Undo", comment: "")
        case .redo: return NSLocalizedString("Redo", comment: "")
        case .bold: return NSLocalizedString("Bold", comment: "")
        case .italic: return NSLocalizedString("Italic", comment: "")
        case .underline: return NSLocalizedString("Underline", comment: "")
        case .checkbox: return NSLocalizedString("Checkbox", comment: "")
        case .subscript: return NSLocalizedString("Sub", comment: "")
        case .superscript: return NSLocalizedString("Super", comment: "")
        case .strike: return NSLocalizedString("Strike", comment: "")
        case .textColor: return NSLocalizedString("Color", comment: "")
        case .selectTextColor: return NSLocalizedString("Select Color", comment: "")
        case .textBackgroundColor: return NSLocalizedString("BG Color", comment: "")
        case .selectTextBackgroundColor: return NSLocalizedString("Select BG Color", comment: "")
        case .header(let h): return NSLocalizedString("H\(h)", comment: "")
        case .indent: return NSLocalizedString("Indent", comment: "")
        case .outdent: return NSLocalizedString("Outdent", comment: "")
        case .orderedList: return NSLocalizedString("Ordered List", comment: "")
        case .unorderedList: return NSLocalizedString("Default", comment: "")
        case .alignLeft: return NSLocalizedString("Left", comment: "")
        case .alignCenter: return NSLocalizedString("Center", comment: "")
        case .alignFull: return NSLocalizedString("Full", comment: "")
        case .alignRight: return NSLocalizedString("Right", comment: "")
        case .image: return NSLocalizedString("Image", comment: "")
        case .video: return NSLocalizedString("Video", comment: "")
        case .link: return NSLocalizedString("Link", comment: "")
        case .table: return NSLocalizedString("Table", comment: "")
        }
    }
    
    public func action(_ toolbar: RichEditorToolbar) {
        switch self {
        case .clear: toolbar.editor?.removeFormat()
        case .undo: toolbar.editor?.undo()
        case .redo: toolbar.editor?.redo()
        case .bold: toolbar.editor?.bold()
        case .italic: toolbar.editor?.italic()
        case .underline: toolbar.editor?.underline()
        case .checkbox: toolbar.editor?.checkbox()
        case .subscript: toolbar.editor?.subscriptText()
        case .superscript: toolbar.editor?.superscript()
        case .strike: toolbar.editor?.strikethrough()
        case .textColor: toolbar.delegate?.richEditorToolbarChangeTextColor?(toolbar)
        case .selectTextColor: toolbar.delegate?.richEditorToolbarChangeSelectTextColor?(toolbar)
        case .textBackgroundColor: toolbar.delegate?.richEditorToolbarChangeBackgroundColor?(toolbar)
        case .selectTextBackgroundColor: toolbar.delegate?.richEditorToolbarChangeSelectTextBackgroundColor?(toolbar)
        case .header(let h): toolbar.editor?.header(h)
        case .indent: toolbar.editor?.indent()
        case .outdent: toolbar.editor?.outdent()
        case .orderedList: toolbar.editor?.orderedList()
        case .unorderedList: toolbar.editor?.unorderedList()
        case .alignLeft: toolbar.editor?.alignLeft()
        case .alignFull: toolbar.editor?.alignFull()
        case .alignCenter: toolbar.editor?.alignCenter()
        case .alignRight: toolbar.editor?.alignRight()
        case .image: toolbar.delegate?.richEditorToolbarInsertImage?(toolbar)
        case .video: toolbar.delegate?.richEditorToolbarInsertVideo?(toolbar)
        case .link: toolbar.delegate?.richEditorToolbarInsertLink?(toolbar)
        case .table: toolbar.delegate?.richEditorToolbarInsertTable?(toolbar)
        }
    }
}
