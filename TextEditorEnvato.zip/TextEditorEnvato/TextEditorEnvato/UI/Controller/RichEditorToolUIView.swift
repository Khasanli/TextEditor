//
//  EditorToolUIView.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 05.06.22.
//

import UIKit

class RichEditorToolUIView: UIView {
    
    let toolbar = RichEditorToolbar()
    var selectedTextUIColor : UIColor = .black {
        didSet {
            self.selectedTextColor.backgroundColor = selectedTextUIColor
            setSelectedTextColor()
        }
    }
        
    var selectedTextBGUIColor : UIColor = .white {
        didSet {
            self.selectedTextBGColor.backgroundColor = selectedTextBGUIColor
            setSelectedTextBGColor()
        }
    }
    
    let bg = UIView(backgroundColor: .tertiarySystemBackground)
    let undoButton = RichEditorToolButton(image: UIImage(systemName: "arrow.uturn.backward"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let redoButton = RichEditorToolButton(image: UIImage(systemName: "arrow.uturn.forward"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let boldButton = RichEditorToolButton(image: UIImage(systemName: "bold"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let italicButton = RichEditorToolButton(image: UIImage(systemName: "italic"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let underlineButton = RichEditorToolButton(image: UIImage(systemName: "underline"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let line = UIView(backgroundColor: UIColor.systemFill.withAlphaComponent(0.3))

    let alignLeftButton = RichEditorToolButton(image: UIImage(systemName: "text.alignleft"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let alignFullButton = RichEditorToolButton(image: UIImage(systemName: "text.justify"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let alignCenterButton = RichEditorToolButton(image: UIImage(systemName: "text.aligncenter"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let alignRightButton = RichEditorToolButton(image: UIImage(systemName: "text.alignright"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let strikeButton = RichEditorToolButton(image: UIImage(systemName: "strikethrough"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let line2 = UIView(backgroundColor: UIColor.systemFill.withAlphaComponent(0.3))

    let outdentButton = RichEditorToolButton(image: UIImage(systemName: "text.chevron.right"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let indentButton = RichEditorToolButton(image: UIImage(systemName: "text.chevron.left"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let unorderedButton = RichEditorToolButton(image: UIImage(systemName: "list.bullet"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let orderedButton = RichEditorToolButton(image: UIImage(systemName: "list.number"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let linkButton = RichEditorToolButton(image: UIImage(systemName: "link"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let InsertNewLinkView = InsertLinkView(backgroundColor: .lightGray.withAlphaComponent(0.5))
    let line3 = UIView(backgroundColor: UIColor.systemFill.withAlphaComponent(0.3))

    let textFontTitle = UILabel(text: "Font Name", backgroundColor: .clear, textColor: .systemGray, font: UIFont(name: "Arial", size: 12)!)
    let textFontBG = UIView(backgroundColor: .secondarySystemFill)
    let textFontButton = RichEditorToolButton(image: nil, title: "Default", tintColor: .black, backgroundColor: .clear)
    let textFontMoreButton = RichEditorToolButton(image: UIImage(systemName: "chevron.down"), title: nil, tintColor: .secondaryLabel, backgroundColor: .clear)
    
    var textFonts : [String] = ["Helvetica", "Arial", "Georgia", "Impact", "Tahoma", "Times New Roman", "Verdana"]
    let TextFontTableViewBG = UIView(backgroundColor: .secondaryLabel)
    var TextFontTableView : UITableView = {
        var tb = UITableView()
        tb.backgroundColor = UIColor(named: "TableViewBG")
        tb.register(UITableViewCell.self, forCellReuseIdentifier: "FontNameCell")
        tb.showsVerticalScrollIndicator = true
        tb.translatesAutoresizingMaskIntoConstraints = false
        return tb
    }()
    
    let textFontSizeTitle = UILabel(text: "Font Size", backgroundColor: .clear, textColor: .systemGray, font: UIFont(name: "Arial", size: 12)!)
    let textFontSizeBG = UIView(backgroundColor: .secondarySystemFill)
    let textFontSizeButton = RichEditorToolButton(image: nil, title: "12", tintColor: .black, backgroundColor: .clear)
    let textFontSizeMoreButton = RichEditorToolButton(image: UIImage(systemName: "chevron.down"), title: nil, tintColor: .secondaryLabel, backgroundColor: .clear)
    
    var textSizes : [Int] = [8, 9, 10, 11, 12, 14, 16, 18, 24, 30, 36, 48, 60, 72, 96]
    let TextSizeTableViewBG = UIView(backgroundColor: .secondaryLabel)
    var TextSizeTableView : UITableView = {
        var tb = UITableView()
        tb.backgroundColor = UIColor(named: "TableViewBG")
        tb.register(UITableViewCell.self, forCellReuseIdentifier: "FontSizeCell")
        tb.showsVerticalScrollIndicator = true
        tb.translatesAutoresizingMaskIntoConstraints = false
        return tb
    }()
    
    let line4 = UIView(backgroundColor: UIColor.systemFill.withAlphaComponent(0.3))

    let textColorTitle = UILabel(text: "Text Color", backgroundColor: .clear, textColor: .systemGray, font: UIFont(name: "Arial", size: 12)!)
    let selectedTextColor = UIButton(image: nil, title: nil, tintColor: .black, backgroundColor: .black)
    let blackTextColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .black)
    let grayTextColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .gray)
    let whiteTextColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .white)
    let selectTextColor = RichEditorToolButton(image: UIImage(systemName: "pencil.circle.fill"), title: nil, tintColor: .clear, backgroundColor: .clear)
    let line5 = UIView(backgroundColor: UIColor.systemFill.withAlphaComponent(0.3))

    let textBGColorTitle = UILabel(text: "Background Color", backgroundColor: .clear, textColor: .systemGray, font: UIFont(name: "Arial", size: 12)!)
    let selectedTextBGColor = UIButton(image: nil, title: nil, tintColor: .black, backgroundColor: .white)
    let blackTextBGColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .black)
    let grayTextBGColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .gray)
    let whiteTextBGColor = UIButton(image: nil, title: nil, tintColor: .gray, backgroundColor: .white)
    let selectTextBGColor = RichEditorToolButton(image: UIImage(systemName: "drop.circle.fill"), title: nil, tintColor: .clear, backgroundColor: .clear)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setView()
    }

    func setView(){
        addSubview(bg)
        bg.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        bg.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        bg.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        bg.heightAnchor.constraint(equalTo: self.heightAnchor).isActive = true
        bg.layer.cornerRadius = 5

        undoButtonConfig()
        redoButtonConfig()
        alignBoldButtonConfig()
        alignItalicButtonConfig()
        alignUnderlineButtonConfig()
        lineConfig()
        
        alignLeftButtonConfig()
        alignFullButtonConfig()
        alignCenterButtonConfig()
        alignRightButtonConfig()
        alignStrikeButtonConfig()
        line2Config()
        
        alignOutdentButtonConfig()
        alignIndentButtonConfig()
        alignUnorderedButtonConfig()
        alignOrderedButtonConfig()
        alignLinkButtonConfig()
        line3Config()
        
        alignFontNameConfig()
        alignFontSizeConfig()
        line4Config()
        
        alignTextColorButtonsConfig()
        alignTextBGColorButtonsConfig()
        
        alignTextFontTableView()
        alignTextFontSizeTableView()
        alignInsertNewLinkView()
    }

    private func undoButtonConfig(){
        addSubview(undoButton)
        undoButton.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        undoButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 12).isActive = true
        undoButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        undoButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        undoButton.backgroundColor = .secondarySystemFill
        undoButton.tintColor = .secondaryLabel
        undoButton.layer.cornerRadius = 3
        let UndoButtonOption = RichEditorDefaultOption.undo
        let UndoButtonHandler = {UndoButtonOption.action(self.toolbar)}
        undoButton.actionHandler = UndoButtonHandler
    }
    
    private func redoButtonConfig(){
        addSubview(redoButton)
        redoButton.leftAnchor.constraint(equalTo: undoButton.rightAnchor, constant: 12).isActive = true
        redoButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 12).isActive = true
        redoButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        redoButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        redoButton.backgroundColor = .secondarySystemFill
        redoButton.tintColor = .secondaryLabel
        redoButton.layer.cornerRadius = 3
        let RedoButtonOption = RichEditorDefaultOption.redo
        let RedoButtonHandler = {RedoButtonOption.action(self.toolbar)}
        redoButton.actionHandler = RedoButtonHandler
    }
    
    private func alignBoldButtonConfig(){
        addSubview(boldButton)
        boldButton.leftAnchor.constraint(equalTo: redoButton.rightAnchor, constant: 12).isActive = true
        boldButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 12).isActive = true
        boldButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        boldButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        boldButton.backgroundColor = .secondarySystemFill
        boldButton.tintColor = .secondaryLabel
        boldButton.layer.cornerRadius = 3
        let BoldButtonOption = RichEditorDefaultOption.bold
        let BoldButtonHandler = {BoldButtonOption.action(self.toolbar)}
        boldButton.actionHandler = BoldButtonHandler
    }
    
    private func alignItalicButtonConfig(){
        addSubview(italicButton)
        italicButton.leftAnchor.constraint(equalTo: boldButton.rightAnchor, constant: 12).isActive = true
        italicButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 12).isActive = true
        italicButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        italicButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        italicButton.backgroundColor = .secondarySystemFill
        italicButton.tintColor = .secondaryLabel
        italicButton.layer.cornerRadius = 3
        let ItalicButtonOption = RichEditorDefaultOption.italic
        let ItalicButtonHandler = {ItalicButtonOption.action(self.toolbar)}
        italicButton.actionHandler = ItalicButtonHandler
    }
    
    private func alignUnderlineButtonConfig(){
        addSubview(underlineButton)
        underlineButton.leftAnchor.constraint(equalTo: italicButton.rightAnchor, constant: 12).isActive = true
        underlineButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 12).isActive = true
        underlineButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        underlineButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        underlineButton.backgroundColor = .secondarySystemFill
        underlineButton.tintColor = .secondaryLabel
        underlineButton.layer.cornerRadius = 3
        let UnderlineButtonOption = RichEditorDefaultOption.underline
        let UnderlineButtonHandler = {UnderlineButtonOption.action(self.toolbar)}
        underlineButton.actionHandler = UnderlineButtonHandler
    }
    
    private func lineConfig(){
        addSubview(line)
        line.topAnchor.constraint(equalTo: underlineButton.bottomAnchor, constant: 10).isActive = true
        line.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        line.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        line.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    private func alignLeftButtonConfig(){
        addSubview(alignLeftButton)
        alignLeftButton.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        alignLeftButton.topAnchor.constraint(equalTo: line.bottomAnchor, constant: 12).isActive = true
        alignLeftButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignLeftButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignLeftButton.backgroundColor = .secondarySystemFill
        alignLeftButton.tintColor = .secondaryLabel
        alignLeftButton.layer.cornerRadius = 3
        let AlignButtonOption = RichEditorDefaultOption.alignLeft
        let AlignButtonHandler = {AlignButtonOption.action(self.toolbar)}
        alignLeftButton.actionHandler = AlignButtonHandler
    }
    
    private func alignFullButtonConfig(){
        addSubview(alignFullButton)
        alignFullButton.leftAnchor.constraint(equalTo: alignLeftButton.rightAnchor, constant: 12).isActive = true
        alignFullButton.topAnchor.constraint(equalTo: line.bottomAnchor, constant: 12).isActive = true
        alignFullButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignFullButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignFullButton.backgroundColor = .secondarySystemFill
        alignFullButton.tintColor = .secondaryLabel
        alignFullButton.layer.cornerRadius = 3
        let AlignButtonOption = RichEditorDefaultOption.alignFull
        let AlignButtonHandler = {AlignButtonOption.action(self.toolbar)}
        alignFullButton.actionHandler = AlignButtonHandler
    }
    
    private func alignCenterButtonConfig(){
        addSubview(alignCenterButton)
        alignCenterButton.leftAnchor.constraint(equalTo: alignFullButton.rightAnchor, constant: 12).isActive = true
        alignCenterButton.topAnchor.constraint(equalTo: line.bottomAnchor, constant: 12).isActive = true
        alignCenterButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignCenterButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignCenterButton.backgroundColor = .secondarySystemFill
        alignCenterButton.tintColor = .secondaryLabel
        alignCenterButton.layer.cornerRadius = 3
        let AlignButtonOption = RichEditorDefaultOption.alignCenter
        let AlignButtonHandler = {AlignButtonOption.action(self.toolbar)}
        alignCenterButton.actionHandler = AlignButtonHandler
    }
    
    private func alignRightButtonConfig(){
        addSubview(alignRightButton)
        alignRightButton.leftAnchor.constraint(equalTo: alignCenterButton.rightAnchor, constant: 12).isActive = true
        alignRightButton.topAnchor.constraint(equalTo:  line.bottomAnchor, constant: 12).isActive = true
        alignRightButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignRightButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        alignRightButton.backgroundColor = .secondarySystemFill
        alignRightButton.tintColor = .secondaryLabel
        alignRightButton.layer.cornerRadius = 3
        let AlignButtonOption = RichEditorDefaultOption.alignRight
        let AlignButtonHandler = {AlignButtonOption.action(self.toolbar)}
        alignRightButton.actionHandler = AlignButtonHandler
    }
    
    private func alignStrikeButtonConfig(){
        addSubview(strikeButton)
        strikeButton.leftAnchor.constraint(equalTo: alignRightButton.rightAnchor, constant: 12).isActive = true
        strikeButton.topAnchor.constraint(equalTo: line.topAnchor, constant: 12).isActive = true
        strikeButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        strikeButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        strikeButton.backgroundColor = .secondarySystemFill
        strikeButton.tintColor = .secondaryLabel
        strikeButton.layer.cornerRadius = 3
        let StrikeButtonOption = RichEditorDefaultOption.strike
        let StrikeButtonHandler = {StrikeButtonOption.action(self.toolbar)}
        strikeButton.actionHandler = StrikeButtonHandler
    }
    
    private func line2Config(){
        addSubview(line2)
        line2.topAnchor.constraint(equalTo: strikeButton.bottomAnchor, constant: 10).isActive = true
        line2.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        line2.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        line2.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    private func alignOutdentButtonConfig(){
        addSubview(outdentButton)
        outdentButton.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        outdentButton.topAnchor.constraint(equalTo:  line2.bottomAnchor, constant: 12).isActive = true
        outdentButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        outdentButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        outdentButton.backgroundColor = .secondarySystemFill
        outdentButton.tintColor = .secondaryLabel
        outdentButton.layer.cornerRadius = 3
        let OutdentButtonOption = RichEditorDefaultOption.outdent
        let OutdentButtonHandler = {OutdentButtonOption.action(self.toolbar)}
        outdentButton.actionHandler = OutdentButtonHandler
    }
    
    private func alignIndentButtonConfig(){
        addSubview(indentButton)
        indentButton.leftAnchor.constraint(equalTo: outdentButton.rightAnchor, constant: 12).isActive = true
        indentButton.topAnchor.constraint(equalTo:  line2.bottomAnchor, constant: 12).isActive = true
        indentButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        indentButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        indentButton.backgroundColor = .secondarySystemFill
        indentButton.tintColor = .secondaryLabel
        indentButton.layer.cornerRadius = 3
        let IndentButtonOption = RichEditorDefaultOption.indent
        let IndentButtonHandler = {IndentButtonOption.action(self.toolbar)}
        indentButton.actionHandler = IndentButtonHandler
    }
    
    private func alignUnorderedButtonConfig(){
        addSubview(unorderedButton)
        unorderedButton.leftAnchor.constraint(equalTo: indentButton.rightAnchor, constant: 12).isActive = true
        unorderedButton.topAnchor.constraint(equalTo: line2.topAnchor, constant: 12).isActive = true
        unorderedButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        unorderedButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        unorderedButton.backgroundColor = .secondarySystemFill
        unorderedButton.tintColor = .secondaryLabel
        unorderedButton.layer.cornerRadius = 3
        let UnorderedListButtonOption = RichEditorDefaultOption.unorderedList
        let UnorderedListButtonHandler = {UnorderedListButtonOption.action(self.toolbar)}
        unorderedButton.actionHandler = UnorderedListButtonHandler
    }
    
    private func alignOrderedButtonConfig(){
        addSubview(orderedButton)
        orderedButton.leftAnchor.constraint(equalTo: unorderedButton.rightAnchor, constant: 12).isActive = true
        orderedButton.topAnchor.constraint(equalTo: line2.topAnchor, constant: 12).isActive = true
        orderedButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        orderedButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        orderedButton.backgroundColor = .secondarySystemFill
        orderedButton.tintColor = .secondaryLabel
        orderedButton.layer.cornerRadius = 3
        let OrderedListButtonOption = RichEditorDefaultOption.orderedList
        let OrderedListButtonHandler = {OrderedListButtonOption.action(self.toolbar)}
        orderedButton.actionHandler = OrderedListButtonHandler
    }

    private func alignLinkButtonConfig(){
        addSubview(linkButton)
        linkButton.leftAnchor.constraint(equalTo: orderedButton.rightAnchor, constant: 12).isActive = true
        linkButton.topAnchor.constraint(equalTo: line2.topAnchor, constant: 12).isActive = true
        linkButton.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        linkButton.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        linkButton.backgroundColor = .secondarySystemFill
        linkButton.tintColor = .secondaryLabel
        linkButton.layer.cornerRadius = 3
        linkButton.addTarget(self, action: #selector(openInsertLinkView), for: .touchUpInside)
    }
    
    private func alignInsertNewLinkView(){
        addSubview(InsertNewLinkView)
        InsertNewLinkView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        InsertNewLinkView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        InsertNewLinkView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        InsertNewLinkView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        InsertNewLinkView.isHidden = true

        let gestureLinkView = UITapGestureRecognizer(target: self, action:  #selector (openInsertLinkView))
        InsertNewLinkView.bg.addGestureRecognizer(gestureLinkView)
        InsertNewLinkView.InsertButton.addTarget(self, action: #selector(insertLink), for: .touchUpInside)
    }

    private func line3Config(){
        addSubview(line3)
        line3.topAnchor.constraint(equalTo: linkButton.bottomAnchor, constant: 10).isActive = true
        line3.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        line3.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        line3.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    private func alignFontNameConfig(){
        addSubview(textFontTitle)
        textFontTitle.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        textFontTitle.topAnchor.constraint(equalTo: line3.bottomAnchor, constant: 6).isActive = true
        textFontTitle.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 2/3, constant: -15).isActive = true
        textFontTitle.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textFontTitle.backgroundColor = .clear
        textFontTitle.tintColor = .secondaryLabel
        textFontTitle.textAlignment = .left
        
        addSubview(textFontBG)
        textFontBG.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        textFontBG.topAnchor.constraint(equalTo: textFontTitle.bottomAnchor).isActive = true
        textFontBG.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 2/3, constant: -15).isActive = true
        textFontBG.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textFontBG.backgroundColor = .secondarySystemFill
        textFontBG.tintColor = .secondaryLabel
        textFontBG.layer.cornerRadius = 3
        
        addSubview(textFontButton)
        textFontButton.leftAnchor.constraint(equalTo: textFontBG.leftAnchor, constant: 10).isActive = true
        textFontButton.centerYAnchor.constraint(equalTo: textFontBG.centerYAnchor).isActive = true
        textFontButton.widthAnchor.constraint(equalTo: textFontBG.widthAnchor, constant: -35).isActive = true
        textFontButton.heightAnchor.constraint(equalTo: textFontBG.heightAnchor).isActive = true
        textFontButton.backgroundColor = .clear
        textFontButton.setTitleColor(.secondaryLabel, for: .normal)
        textFontButton.contentHorizontalAlignment = .left
        textFontButton.titleLabel?.font = UIFont(name: "Arial", size: 12)

        addSubview(textFontMoreButton)
        textFontMoreButton.rightAnchor.constraint(equalTo: textFontBG.rightAnchor, constant: -5).isActive = true
        textFontMoreButton.centerYAnchor.constraint(equalTo: textFontBG.centerYAnchor).isActive = true
        textFontMoreButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        textFontMoreButton.heightAnchor.constraint(equalToConstant: 10).isActive = true
        textFontMoreButton.addTarget(self, action: #selector(openTextFontTableView), for: .touchUpInside)
    }
    
    private func alignTextFontTableView(){
        addSubview(TextFontTableViewBG)
        TextFontTableViewBG.rightAnchor.constraint(equalTo: textFontBG.rightAnchor).isActive = true
        TextFontTableViewBG.topAnchor.constraint(equalTo: textFontBG.bottomAnchor, constant: 2).isActive = true
        TextFontTableViewBG.heightAnchor.constraint(equalToConstant: 98).isActive = true
        TextFontTableViewBG.leftAnchor.constraint(equalTo: textFontBG.leftAnchor).isActive = true
        TextFontTableViewBG.layer.shadowColor = UIColor.lightGray.cgColor
        TextFontTableViewBG.isHidden = true
        TextFontTableViewBG.backgroundColor = .secondarySystemFill
        TextFontTableViewBG.layer.shadowRadius = 3
        TextFontTableViewBG.layer.shadowOpacity = 0.5
        
        addSubview(TextFontTableView)
        TextFontTableView.rightAnchor.constraint(equalTo: textFontBG.rightAnchor).isActive = true
        TextFontTableView.topAnchor.constraint(equalTo: textFontBG.bottomAnchor).isActive = true
        TextFontTableView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        TextFontTableView.leftAnchor.constraint(equalTo: textFontBG.leftAnchor).isActive = true
        TextFontTableView.isHidden = true
        TextFontTableView.delegate = self
        TextFontTableView.dataSource = self
        
    }
    
    private func alignFontSizeConfig(){
        addSubview(textFontSizeTitle)
        textFontSizeTitle.leftAnchor.constraint(equalTo: textFontBG.rightAnchor, constant: 12).isActive = true
        textFontSizeTitle.topAnchor.constraint(equalTo: line3.bottomAnchor, constant: 6).isActive = true
        textFontSizeTitle.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/3, constant: -15).isActive = true
        textFontSizeTitle.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textFontSizeTitle.backgroundColor = .clear
        textFontSizeTitle.tintColor = .secondaryLabel
        textFontSizeTitle.textAlignment = .left
        
        addSubview(textFontSizeBG)
        textFontSizeBG.leftAnchor.constraint(equalTo: textFontSizeTitle.leftAnchor).isActive = true
        textFontSizeBG.topAnchor.constraint(equalTo: textFontSizeTitle.bottomAnchor).isActive = true
        textFontSizeBG.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -12).isActive = true
        textFontSizeBG.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textFontSizeBG.backgroundColor = .secondarySystemFill
        textFontSizeBG.tintColor = .secondaryLabel
        textFontSizeBG.layer.cornerRadius = 3
        
        addSubview(textFontSizeButton)
        textFontSizeButton.leftAnchor.constraint(equalTo: textFontSizeBG.leftAnchor, constant: 5).isActive = true
        textFontSizeButton.centerYAnchor.constraint(equalTo: textFontSizeBG.centerYAnchor).isActive = true
        textFontSizeButton.widthAnchor.constraint(equalTo: textFontSizeBG.widthAnchor, constant: -35).isActive = true
        textFontSizeButton.heightAnchor.constraint(equalTo: textFontSizeBG.heightAnchor).isActive = true
        textFontSizeButton.backgroundColor = .clear
        textFontSizeButton.contentHorizontalAlignment = .left
        textFontSizeButton.titleLabel?.font = UIFont(name: "Arial", size: 12)
        textFontSizeButton.setTitleColor(.secondaryLabel, for: .normal)

        addSubview(textFontSizeMoreButton)
        textFontSizeMoreButton.rightAnchor.constraint(equalTo: textFontSizeBG.rightAnchor, constant: -5).isActive = true
        textFontSizeMoreButton.centerYAnchor.constraint(equalTo: textFontBG.centerYAnchor).isActive = true
        textFontSizeMoreButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        textFontSizeMoreButton.heightAnchor.constraint(equalToConstant: 10).isActive = true
        textFontSizeMoreButton.addTarget(self, action: #selector(openTextSizeTableView), for: .touchUpInside)
    }
    
    private func alignTextFontSizeTableView(){
        addSubview(TextSizeTableViewBG)
        TextSizeTableViewBG.leftAnchor.constraint(equalTo: textFontSizeBG.leftAnchor, constant: -20).isActive = true
        TextSizeTableViewBG.topAnchor.constraint(equalTo: textFontSizeBG.bottomAnchor).isActive = true
        TextSizeTableViewBG.heightAnchor.constraint(equalToConstant: 100).isActive = true
        TextSizeTableViewBG.rightAnchor.constraint(equalTo: textFontSizeBG.rightAnchor).isActive = true
        TextSizeTableViewBG.layer.shadowColor = UIColor.lightGray.cgColor
        TextSizeTableViewBG.isHidden = true
        TextSizeTableViewBG.backgroundColor = .white
        TextSizeTableViewBG.layer.shadowRadius = 3
        TextSizeTableViewBG.layer.shadowOpacity = 0.5
        
        addSubview(TextSizeTableView)
        TextSizeTableView.leftAnchor.constraint(equalTo: textFontSizeBG.leftAnchor, constant: -20).isActive = true
        TextSizeTableView.topAnchor.constraint(equalTo: textFontSizeBG.bottomAnchor).isActive = true
        TextSizeTableView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        TextSizeTableView.rightAnchor.constraint(equalTo: textFontSizeBG.rightAnchor).isActive = true
        TextSizeTableView.isHidden = true
        TextSizeTableView.delegate = self
        TextSizeTableView.dataSource = self
    }
        
    private func line4Config(){
        addSubview(line4)
        line4.topAnchor.constraint(equalTo: textFontSizeButton.bottomAnchor, constant: 10).isActive = true
        line4.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        line4.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        line4.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    private func alignTextColorButtonsConfig(){
        addSubview(textColorTitle)
        textColorTitle.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        textColorTitle.topAnchor.constraint(equalTo: line4.bottomAnchor, constant: 6).isActive = true
        textColorTitle.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/2, constant: -15).isActive = true
        textColorTitle.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textColorTitle.backgroundColor = .clear
        textColorTitle.tintColor = .secondaryLabel
        textColorTitle.textAlignment = .left
        
        addSubview(selectedTextColor)
        selectedTextColor.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        selectedTextColor.topAnchor.constraint(equalTo: textColorTitle.bottomAnchor).isActive = true
        selectedTextColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectedTextColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectedTextColor.layer.cornerRadius = 3
        selectedTextColor.layer.borderWidth = 2
        selectedTextColor.layer.borderColor = UIColor.lightGray.cgColor
        selectedTextColor.addTarget(self, action: #selector(setSelectedTextColor), for: .touchUpInside)
        
        addSubview(blackTextColor)
        blackTextColor.leftAnchor.constraint(equalTo: selectedTextColor.rightAnchor, constant: 6).isActive = true
        blackTextColor.topAnchor.constraint(equalTo: textColorTitle.bottomAnchor).isActive = true
        blackTextColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        blackTextColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        blackTextColor.layer.cornerRadius = 3
        blackTextColor.addTarget(self, action: #selector(setBlackTextColor), for: .touchUpInside)
        
        addSubview(grayTextColor)
        grayTextColor.leftAnchor.constraint(equalTo: blackTextColor.rightAnchor, constant: 6).isActive = true
        grayTextColor.topAnchor.constraint(equalTo: textColorTitle.bottomAnchor).isActive = true
        grayTextColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        grayTextColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        grayTextColor.layer.cornerRadius = 3
        grayTextColor.addTarget(self, action: #selector(setGrayTextColor), for: .touchUpInside)

        addSubview(whiteTextColor)
        whiteTextColor.leftAnchor.constraint(equalTo: grayTextColor.rightAnchor, constant: 6).isActive = true
        whiteTextColor.topAnchor.constraint(equalTo: textColorTitle.bottomAnchor).isActive = true
        whiteTextColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        whiteTextColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        whiteTextColor.layer.cornerRadius = 3
        whiteTextColor.layer.borderWidth = 1
        whiteTextColor.layer.borderColor = UIColor.lightGray.cgColor
        whiteTextColor.addTarget(self, action: #selector(setWhiteTextColor), for: .touchUpInside)

        addSubview(selectTextColor)
        selectTextColor.leftAnchor.constraint(equalTo: whiteTextColor.rightAnchor, constant: 6).isActive = true
        selectTextColor.topAnchor.constraint(equalTo: textColorTitle.bottomAnchor).isActive = true
        selectTextColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectTextColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectTextColor.layer.cornerRadius = 3
        selectTextColor.backgroundColor = .secondarySystemFill
        selectTextColor.tintColor = .secondaryLabel
        
        addSubview(line5)
        line5.topAnchor.constraint(equalTo: selectTextColor.bottomAnchor, constant: 10).isActive = true
        line5.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
        line5.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        line5.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    
    private func alignTextBGColorButtonsConfig(){
        addSubview(textBGColorTitle)
        textBGColorTitle.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        textBGColorTitle.topAnchor.constraint(equalTo: line5.bottomAnchor, constant: 6).isActive = true
        textBGColorTitle.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/2, constant: -15).isActive = true
        textBGColorTitle.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        textBGColorTitle.backgroundColor = .clear
        textBGColorTitle.tintColor = .secondaryLabel
        textBGColorTitle.textAlignment = .left
        
        addSubview(selectedTextBGColor)
        selectedTextBGColor.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 12).isActive = true
        selectedTextBGColor.topAnchor.constraint(equalTo: textBGColorTitle.bottomAnchor).isActive = true
        selectedTextBGColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectedTextBGColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectedTextBGColor.layer.cornerRadius = 3
        selectedTextBGColor.layer.borderWidth = 2
        selectedTextBGColor.layer.borderColor = UIColor.lightGray.cgColor
        selectedTextBGColor.addTarget(self, action: #selector(setSelectedTextBGColor), for: .touchUpInside)

        addSubview(blackTextBGColor)
        blackTextBGColor.leftAnchor.constraint(equalTo: selectedTextBGColor.rightAnchor, constant: 6).isActive = true
        blackTextBGColor.topAnchor.constraint(equalTo: textBGColorTitle.bottomAnchor).isActive = true
        blackTextBGColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        blackTextBGColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        blackTextBGColor.layer.cornerRadius = 3
        blackTextBGColor.addTarget(self, action: #selector(setBlackTextBGColor), for: .touchUpInside)

        addSubview(grayTextBGColor)
        grayTextBGColor.leftAnchor.constraint(equalTo: blackTextBGColor.rightAnchor, constant: 6).isActive = true
        grayTextBGColor.topAnchor.constraint(equalTo: textBGColorTitle.bottomAnchor).isActive = true
        grayTextBGColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        grayTextBGColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        grayTextBGColor.layer.cornerRadius = 3
        grayTextBGColor.addTarget(self, action: #selector(setGrayTextBGColor), for: .touchUpInside)

        addSubview(whiteTextBGColor)
        whiteTextBGColor.leftAnchor.constraint(equalTo: grayTextBGColor.rightAnchor, constant: 6).isActive = true
        whiteTextBGColor.topAnchor.constraint(equalTo: textBGColorTitle.bottomAnchor).isActive = true
        whiteTextBGColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        whiteTextBGColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        whiteTextBGColor.layer.cornerRadius = 3
        whiteTextBGColor.layer.borderWidth = 1
        whiteTextBGColor.layer.borderColor = UIColor.lightGray.cgColor
        whiteTextBGColor.addTarget(self, action: #selector(setWhiteTextBGColor), for: .touchUpInside)

        addSubview(selectTextBGColor)
        selectTextBGColor.leftAnchor.constraint(equalTo: whiteTextBGColor.rightAnchor, constant: 6).isActive = true
        selectTextBGColor.topAnchor.constraint(equalTo: textBGColorTitle.bottomAnchor).isActive = true
        selectTextBGColor.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectTextBGColor.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1/5, constant: -15).isActive = true
        selectTextBGColor.layer.cornerRadius = 3
        selectTextBGColor.backgroundColor = .secondarySystemFill
        selectTextBGColor.tintColor = .secondaryLabel
    }
    
    @objc func setWhiteTextColor(){
        self.selectedTextColor.backgroundColor = .white
        self.toolbar.editor?.setTextColor(.white)
    }
    @objc func setBlackTextColor(){
        self.selectedTextColor.backgroundColor = .black
        self.toolbar.editor?.setTextColor(.black)
    }
    @objc func setGrayTextColor(){
        self.selectedTextColor.backgroundColor = .gray
        self.toolbar.editor?.setTextColor(.gray)
    }
    @objc func setSelectedTextColor(){
        self.toolbar.editor?.setTextColor(selectedTextUIColor)
    }
    @objc func setWhiteTextBGColor(){
        self.selectedTextBGColor.backgroundColor = .white
        self.toolbar.editor?.setTextBackgroundColor(.white)
    }
    @objc func setBlackTextBGColor(){
        self.selectTextBGColor.backgroundColor = .black
        self.toolbar.editor?.setTextBackgroundColor(.black)
    }
    @objc func setGrayTextBGColor(){
        self.selectTextBGColor.backgroundColor = .gray
        self.toolbar.editor?.setTextBackgroundColor(.gray)
    }
    @objc func setSelectedTextBGColor(){
        self.toolbar.editor?.setTextBackgroundColor(selectedTextBGUIColor)
    }
    
    
    @objc func openTextSizeTableView(){
        if TextSizeTableView.isHidden {
            UIView.animate(withDuration: 0.5) {
                self.TextSizeTableView.isHidden = false
                self.TextSizeTableViewBG.isHidden = false
                if !self.TextFontTableView.isHidden{
                    self.TextFontTableView.isHidden = true
                    self.TextFontTableViewBG.isHidden = true
                }
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.TextSizeTableView.isHidden = true
                self.TextSizeTableViewBG.isHidden = true
            }
        }
    }
    
    @objc func openTextFontTableView(){
        if TextFontTableView.isHidden {
            UIView.animate(withDuration: 0.5) {
                self.TextFontTableView.isHidden = false
                self.TextFontTableViewBG.isHidden = false
                if !self.TextSizeTableView.isHidden{
                    self.TextSizeTableView.isHidden = true
                    self.TextSizeTableViewBG.isHidden = true
                }
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.TextFontTableViewBG.isHidden = true
                self.TextFontTableView.isHidden = true
            }
        }
    }
    
    @objc func openInsertLinkView(){
        if InsertNewLinkView.isHidden {
            UIView.animate(withDuration: 0.5) {
                self.InsertNewLinkView.isHidden = false
            }
        } else {
            UIView.animate(withDuration: 0.5) {
                self.InsertNewLinkView.isHidden = true
            }
        }
    }
    
    @objc func insertLink(){
        if !InsertNewLinkView.httpTextField.text!.isEmpty && !InsertNewLinkView.textTextField.text!.isEmpty {
            self.toolbar.editor?.insertLink(href: InsertNewLinkView.httpTextField.text!, text: InsertNewLinkView.textTextField.text!)
            self.openInsertLinkView()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension RichEditorToolUIView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == TextSizeTableView {
            return textSizes.count
        } else {
            return textFonts.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == TextSizeTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FontSizeCell", for: indexPath)
            let option = String(textSizes[indexPath.row])
            cell.backgroundColor = .clear
            cell.tintColor = .secondaryLabel
            cell.textLabel?.text = option
            cell.textLabel?.font = UIFont(name: option, size: 11)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FontNameCell", for: indexPath)
            let option = String(textFonts[indexPath.row])
            cell.backgroundColor = .clear
            cell.tintColor = .secondaryLabel
            cell.textLabel?.text = option
            cell.textLabel?.font = UIFont(name: option, size: 11)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == TextSizeTableView {
            DispatchQueue.main.async {
                self.openTextSizeTableView()
                let size = self.textSizes[indexPath.row]
                self.toolbar.editor?.setFontSize(size)
                self.textFontSizeButton.setTitle("\(size)", for: .normal)
            }
        } else{
            DispatchQueue.main.async {
                self.openTextFontTableView()
                let font = self.textFonts[indexPath.row]
                self.toolbar.editor?.setFontName(font)
                self.textFontButton.setTitle(font, for: .normal)
            }
        }
    }
}

