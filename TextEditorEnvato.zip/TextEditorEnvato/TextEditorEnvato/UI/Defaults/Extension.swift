//
//  Convenience.swift
//  TextEditorForSale
//
//  Created by Khayala Hasanli on 04.06.22.
//

import UIKit
let screenSize = UIScreen.main.bounds

extension UIApplication {
    var keyWindow: UIWindow? {
        return UIApplication.shared.connectedScenes
            .filter { $0.activationState == .foregroundActive }
            .first(where: { $0 is UIWindowScene })
            .flatMap({ $0 as? UIWindowScene })?.windows
            .first(where: \.isKeyWindow)
    }
}

extension UIColor {
   static func setColor(lightColor: UIColor, darkColor: UIColor) -> UIColor {
        if #available(iOS 13, *) {
            return UIColor{ (traitCollection) -> UIColor in
                return traitCollection.userInterfaceStyle == .light ? lightColor : darkColor
            }
        } else {
            return lightColor
        }
    }
    
}

extension UILabel {
    convenience init(text: String, backgroundColor: UIColor?, textColor: UIColor?, font: UIFont) {
        self.init()
        self.adjustsFontSizeToFitWidth = true
        self.translatesAutoresizingMaskIntoConstraints = false
        self.font = font
        self.text = text
        self.textAlignment = .center
        if backgroundColor != nil {
            self.textColor = textColor
            self.backgroundColor = backgroundColor
        } else {
            self.textColor = textColor
            self.backgroundColor = .clear
        }
    }
  
}

extension UIButton {
    convenience init(configuration: Bool = false, image: UIImage?, title: String?, tintColor: UIColor, backgroundColor: UIColor) {
        self.init()
        let tintedImage = image?.withRenderingMode(.alwaysTemplate)

        self.translatesAutoresizingMaskIntoConstraints = false
        self.setImage(tintedImage, for: .normal)
        self.setTitle(title, for: .normal)
        self.setTitleColor(tintColor, for: .normal)
        self.tintColor = tintColor

        if tintedImage != nil {
            self.backgroundColor = .clear
        } else {
            self.backgroundColor = backgroundColor
        }
        
        if configuration {
            if #available(iOS 15.0, *) {
                var configuration = UIButton.Configuration.gray()
                configuration.baseBackgroundColor  = .clear
                self.configuration = configuration
            }
        }
    }
}

extension UIView {
    convenience init(backgroundColor: UIColor) {
        self.init()
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = backgroundColor
    }
}

extension UITextField {
    convenience init(placeholder: String, backgroundColor: UIColor?, textColor: UIColor, font: UIFont) {
        self.init()
        self.adjustsFontSizeToFitWidth = true
        self.translatesAutoresizingMaskIntoConstraints = false
        self.font = font
        self.text = text
        self.textColor = textColor
        self.backgroundColor = backgroundColor
        self.leftViewMode = .always
        self.textAlignment = .center
        self.attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [NSAttributedString.Key.foregroundColor: textColor])
    }
}


