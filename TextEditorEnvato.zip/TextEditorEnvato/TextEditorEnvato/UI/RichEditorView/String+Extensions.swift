//
//  String+Extensions.swift
//  Pods
//
//  Created by Caesar Wirth on 10/9/16.
//
//
import Foundation

extension String {
    var escaped: String {
        let unicode = self.unicodeScalars
        var newString = ""
        for char in unicode {
            if char.value == 39 ||
                char.value < 9 ||
                (char.value > 9 && char.value < 32)
            {
                let escaped = char.escaped(asASCII: true)
                newString.append(escaped)
            } else {
                newString.append(String(char))
            }
        }
        return newString
    }
}
